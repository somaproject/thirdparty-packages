"""
Utility scripts for PyTables
============================

:Author:   Francesc Alted
:Contact:  faltet@pytables.org
:Created:  2008-03-05
:License:  BSD
:Revision: $Id: __init__.py 3698 2008-09-09 12:54:51Z faltet $

This package contains some modules which provide a ``main()`` function
(with no arguments), so that they can be used as scripts.
"""
