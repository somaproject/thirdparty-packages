"""
Unit tests for special node behaviours
======================================

:Author:   Ivan Vilata i Balaguer
:Contact:  ivan@selidor.net
:Created:  2007-01-18
:License:  BSD
:Revision: $Id: __init__.py 3698 2008-09-09 12:54:51Z faltet $
"""
