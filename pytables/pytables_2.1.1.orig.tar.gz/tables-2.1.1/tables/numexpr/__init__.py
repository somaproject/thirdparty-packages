from tables.numexpr.info import __doc__
from tables.numexpr.expressions import E
from tables.numexpr.compiler import numexpr, disassemble, evaluate

