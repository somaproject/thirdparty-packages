#!/bin/sh
PYTHON=python2.5
# Small script to check the example repository quickly
$PYTHON array1.py
$PYTHON array2.py
$PYTHON array3.py
$PYTHON array4.py
$PYTHON attributes1.py
$PYTHON earray1.py
$PYTHON earray2.py
$PYTHON objecttree.py
$PYTHON table1.py
$PYTHON table2.py
$PYTHON table-tree.py
$PYTHON tutorial1-1.py
$PYTHON tutorial1-2.py
#$PYTHON tutorial2.py   # This should always fail at the beginning
$PYTHON vlarray1.py
$PYTHON vlarray2.py
$PYTHON vlarray3.py
$PYTHON nested1.py
$PYTHON nested-tut.py
$PYTHON nested-iter.py
