HDF5 version 1.8.3 released on Wed May 13 10:58:40 CDT 2009
==> README.txt <==
Messages sent to the list should be addressed to "<list>@hdfgroup.org".

Periodic code snapshots are provided at the following URL:
    ftp://ftp.hdfgroup.uiuc.edu/pub/outgoing/hdf5/snapshots
Please read the README.txt file in that directory before working with a 
library snapshot.

The HDF5 website is located at http://hdfgroup.org/HDF5/

Bugs should be reported to help@hdfgroup.org.
